package com.qaryu.finance;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private final List<Player> players = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout list;
    private TextView totalPlayers, paidTotal, unpaidTotal;
    private EditText search;

    static class Player {
        String name; int amount; boolean paid;
        Player(String n,int a,boolean p){name=n;amount=a;paid=p;}
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("finance",MODE_PRIVATE);
        list=findViewById(R.id.listContainer);
        totalPlayers=findViewById(R.id.totalPlayers);
        paidTotal=findViewById(R.id.paidTotal);
        unpaidTotal=findViewById(R.id.unpaidTotal);
        search=findViewById(R.id.searchInput);
        load();
        findViewById(R.id.addButton).setOnClickListener(v -> addPlayer());
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){render();}
            public void afterTextChanged(Editable e){}
        });
        render();
    }

    private void addPlayer(){
        EditText name=findViewById(R.id.nameInput);
        EditText amount=findViewById(R.id.amountInput);
        String n=name.getText().toString().trim();
        if(n.isEmpty()){ name.setError("اكتب اسم اللاعب"); return; }
        int a=1000;
        try { a=Integer.parseInt(amount.getText().toString().trim()); } catch(Exception ignored){}
        players.add(new Player(n,a,false));
        save(); name.setText(""); amount.setText("1000"); render();
    }

    private void render(){
        list.removeAllViews();
        String q=search.getText().toString().trim().toLowerCase();
        int paid=0, unpaid=0;
        for(Player p:players){ if(p.paid) paid+=p.amount; else unpaid+=p.amount; }
        totalPlayers.setText("اللاعبون\n"+players.size());
        paidTotal.setText("المدفوع\n"+paid+" ريال");
        unpaidTotal.setText("المتبقي\n"+unpaid+" ريال");

        for(Player p:players){
            if(!p.name.toLowerCase().contains(q)) continue;
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(14,14,14,14);
            row.setBackgroundColor(0xFFFFFFFF);

            TextView title=new TextView(this);
            title.setText(p.name+" — "+p.amount+" ريال");
            title.setTextSize(18); title.setGravity(Gravity.RIGHT);
            title.setTextDirection(View.TEXT_DIRECTION_RTL);

            Button pay=new Button(this);
            pay.setText(p.paid ? "تم الدفع ✓" : "لم يدفع — اضغط لتسجيل الدفع");
            pay.setOnClickListener(v->{p.paid=!p.paid;save();render();});

            Button del=new Button(this);
            del.setText("حذف اللاعب");
            del.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("حذف اللاعب")
                .setMessage("هل تريد حذف "+p.name+"؟")
                .setPositiveButton("حذف",(d,w)->{players.remove(p);save();render();})
                .setNegativeButton("إلغاء",null).show());

            row.addView(title); row.addView(pay); row.addView(del);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);
            rp.setMargins(0,8,0,8);
            list.addView(row,rp);
        }
    }

    private void save(){
        JSONArray a=new JSONArray();
        for(Player p:players) try{
            JSONObject o=new JSONObject();
            o.put("name",p.name); o.put("amount",p.amount); o.put("paid",p.paid); a.put(o);
        }catch(Exception ignored){}
        prefs.edit().putString("players",a.toString()).apply();
    }

    private void load(){
        try{
            JSONArray a=new JSONArray(prefs.getString("players","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                players.add(new Player(o.getString("name"),o.getInt("amount"),o.getBoolean("paid")));
            }
        }catch(Exception ignored){}
    }
}
